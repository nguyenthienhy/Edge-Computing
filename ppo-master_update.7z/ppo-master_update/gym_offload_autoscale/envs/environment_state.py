from enum import Enum

class EnvironmentState(Enum):
    low = 0
    med = 1
    high = 2